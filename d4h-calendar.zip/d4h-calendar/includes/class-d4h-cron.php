<?php
/**
 * Cron: custom interval, schedule sync event, run sync on hook.
 *
 * @package D4H_Calendar
 */

namespace D4H_Calendar;

defined( 'ABSPATH' ) || exit;

final class Cron {

	/** @var array<string, mixed> */
	private $config;

	/**
	 * @param array<string, mixed> $config
	 */
	public function __construct( array $config ) {
		$this->config = $config;
	}

	public function register_hooks(): void {
		add_filter( 'cron_schedules', array( $this, 'add_schedule' ) );
		add_action( $this->config['cron_hook'] ?? 'd4h_calendar_sync', array( $this, 'run_sync' ) );

		$clean_hook = $this->config['cron_clean_hook'] ?? 'd4h_calendar_clean_and_sync';
		add_action( $clean_hook, array( $this, 'run_clean_and_sync' ) );

		add_action( 'init', array( $this, 'maybe_reschedule' ) );
		add_action( 'init', array( $this, 'maybe_schedule_clean' ) );
	}

	/**
	 * Add custom cron schedule(s).
	 *
	 * @param array<string, array{interval: int, display: string}> $schedules
	 * @return array<string, array{interval: int, display: string}>
	 */
	public function add_schedule( array $schedules ): array {
		$presets = $this->config['cron_interval_presets'] ?? array();
		$default_interval = (int) ( $this->config['cron_interval_sec'] ?? 7200 );
		$default_name     = $this->config['cron_schedule_name'] ?? 'd4h_calendar_every_two_hours';

		foreach ( $presets as $interval_seconds => $preset ) {
			$name   = is_array( $preset ) ? ( $preset['name'] ?? 'd4h_calendar_' . ( $interval_seconds / 3600 ) . 'h' ) : $preset;
			$label  = is_array( $preset ) ? ( $preset['label'] ?? sprintf( __( 'Every %d hours', 'd4h-calendar' ), $interval_seconds / 3600 ) ) : sprintf( __( 'Every %d hours', 'd4h-calendar' ), $interval_seconds / 3600 );
			$schedules[ $name ] = array(
				'interval' => (int) $interval_seconds,
				'display'  => $label,
			);
		}

		// Fallback: add default if not in presets.
		if ( ! isset( $schedules[ $default_name ] ) ) {
			$schedules[ $default_name ] = array(
				'interval' => $default_interval,
				'display'  => sprintf(
					/* translators: %d: interval in hours */
					__( 'Every %d hours', 'd4h-calendar' ),
					$default_interval / 3600
				),
			);
		}
		return $schedules;
	}

	/**
	 * Get effective cron interval and schedule name (option override or config).
	 *
	 * @return array{interval: int, schedule_name: string}
	 */
	private function get_effective_cron_config(): array {
		$option_key  = $this->config['option_cron_interval_sec'] ?? 'd4h_calendar_cron_interval_sec';
		$config_sec  = (int) ( $this->config['cron_interval_sec'] ?? 7200 );
		$config_name = $this->config['cron_schedule_name'] ?? 'd4h_calendar_every_two_hours';
		$presets     = $this->config['cron_interval_presets'] ?? array();

		$option_sec = get_option( $option_key, 0 );
		$option_sec = $option_sec !== '' && $option_sec !== false ? (int) $option_sec : 0;

		if ( $option_sec > 0 && isset( $presets[ $option_sec ] ) ) {
			$preset = $presets[ $option_sec ];
			return array(
				'interval'      => $option_sec,
				'schedule_name' => is_array( $preset ) ? ( $preset['name'] ?? $config_name ) : $config_name,
			);
		}

		return array(
			'interval'      => $config_sec,
			'schedule_name' => $config_name,
		);
	}

	/** @var string Transient key for overlap lock. */
	private const LOCK_KEY = 'd4h_calendar_sync_lock';

	/**
	 * Cron callback: run full sync.
	 */
	public function run_sync(): void {
		if ( empty( $this->config['enable_cron'] ) ) {
			return;
		}

		$token = function_exists( 'd4h_core_get_token' ) ? d4h_core_get_token() : '';
		if ( $token === '' ) {
			return;
		}

		$lock_ttl = (int) ( $this->config['cron_lock_ttl_sec'] ?? 900 );
		if ( get_transient( self::LOCK_KEY ) ) {
			return; // Another sync is already running.
		}
		set_transient( self::LOCK_KEY, 1, $lock_ttl );

		global $wpdb;
		$config = $this->config;
		$config['table_name'] = $wpdb->prefix . ( $config['table_name_prefix'] ?? 'd4h_calendar_' ) . 'activities';

		$option_error  = $this->config['option_last_sync_error'] ?? 'd4h_calendar_last_sync_error';
		$option_status = $this->config['option_last_sync_status'] ?? 'd4h_calendar_last_sync_status';
		$start         = microtime( true );

		try {
			$database   = new Database( $config );
			$repository = new Repository( $config, $database );
			$api        = new API_Client( $config, $token );
			$sync       = new Sync( $config, $api, $repository );

			$result   = $sync->run_full_sync( false ); // Cron: events/exercises only, no tags
			$duration = microtime( true ) - $start;

			if ( is_wp_error( $result ) ) {
				$error_message = $result->get_error_message();
				update_option( $option_error, $error_message, false );
				update_option( $option_status, 'error', false );
				Sync_History::log_sync( $this->config, 'error', $error_message, 'cron', $duration, null, 'calendar' );
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
					error_log( 'D4H Calendar cron sync failed: ' . $error_message );
				}
			} else {
				delete_option( $option_error );
				update_option( $option_status, 'success', false );
				Sync_History::log_sync( $this->config, 'success', '', 'cron', $duration, null, 'calendar' );
			}
		} catch ( \Throwable $exception ) {
			$duration = microtime( true ) - $start;
			$message  = $exception->getMessage();
			update_option( $option_error, $message, false );
			update_option( $option_status, 'error', false );
			Sync_History::log_sync( $this->config, 'error', $message, 'cron', $duration, null, 'calendar' );
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log( 'D4H Calendar cron sync exception: ' . $message );
			}
		} finally {
			delete_transient( self::LOCK_KEY );
		}
	}

	/** @var string Transient key for clean-and-sync lock. */
	private const CLEAN_LOCK_KEY = 'd4h_calendar_clean_lock';

	/**
	 * Cron callback: delete all activities, then run full sync to re-fetch. Removes duplicates.
	 */
	public function run_clean_and_sync(): void {
		if ( empty( $this->config['enable_cron'] ) ) {
			return;
		}

		$token = function_exists( 'd4h_core_get_token' ) ? d4h_core_get_token() : '';
		if ( $token === '' ) {
			return;
		}

		$lock_ttl = (int) ( $this->config['cron_lock_ttl_sec'] ?? 900 );
		if ( get_transient( self::CLEAN_LOCK_KEY ) ) {
			return;
		}
		set_transient( self::CLEAN_LOCK_KEY, 1, $lock_ttl );

		global $wpdb;
		$config = $this->config;
		$config['table_name'] = $wpdb->prefix . ( $config['table_name_prefix'] ?? 'd4h_calendar_' ) . 'activities';

		$option_error  = $this->config['option_last_sync_error'] ?? 'd4h_calendar_last_sync_error';
		$option_status = $this->config['option_last_sync_status'] ?? 'd4h_calendar_last_sync_status';
		$start         = microtime( true );

		try {
			$database   = new Database( $config );
			$repository = new Repository( $config, $database );
			$api        = new API_Client( $config, $token );
			$sync       = new Sync( $config, $api, $repository );

			$repository->delete_all();
			$result   = $sync->run_full_sync( false );
			$duration = microtime( true ) - $start;

			if ( is_wp_error( $result ) ) {
				$error_message = $result->get_error_message();
				update_option( $option_error, $error_message, false );
				update_option( $option_status, 'error', false );
				Sync_History::log_sync( $this->config, 'error', $error_message, 'cron_clean', $duration, null, 'calendar' );
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
					error_log( 'D4H Calendar clean-and-sync cron failed: ' . $error_message );
				}
			} else {
				delete_option( $option_error );
				update_option( $option_status, 'success', false );
				Sync_History::log_sync( $this->config, 'success', '', 'cron_clean', $duration, null, 'calendar' );
			}
		} catch ( \Throwable $exception ) {
			$duration = microtime( true ) - $start;
			$message  = $exception->getMessage();
			update_option( $option_error, $message, false );
			update_option( $option_status, 'error', false );
			Sync_History::log_sync( $this->config, 'error', $message, 'cron_clean', $duration, null, 'calendar' );
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
				error_log( 'D4H Calendar clean-and-sync cron exception: ' . $message );
			}
		} finally {
			delete_transient( self::CLEAN_LOCK_KEY );
		}
	}

	/**
	 * Schedule the clean-and-sync cron if not already scheduled.
	 */
	public function maybe_schedule_clean(): void {
		if ( empty( $this->config['enable_cron'] ) ) {
			return;
		}

		$hook_name  = $this->config['cron_clean_hook'] ?? 'd4h_calendar_clean_and_sync';
		$schedule   = $this->config['cron_clean_schedule_name'] ?? 'd4h_calendar_12h';

		if ( ! wp_next_scheduled( $hook_name ) ) {
			wp_schedule_event( time(), $schedule, $hook_name );
		}
	}

	/**
	 * Schedule the cron event. Call on activation.
	 */
	public function schedule(): void {
		$hook_name   = $this->config['cron_hook'] ?? 'd4h_calendar_sync';
		$effective   = $this->get_effective_cron_config();

		if ( ! wp_next_scheduled( $hook_name ) ) {
			wp_schedule_event( time(), $effective['schedule_name'], $hook_name );
		}
	}

	/**
	 * If config/option schedule or interval changed, unschedule and reschedule. Runs on init.
	 */
	public function maybe_reschedule(): void {
		if ( empty( $this->config['enable_cron'] ) ) {
			return;
		}

		$hook_name   = $this->config['cron_hook'] ?? 'd4h_calendar_sync';
		$effective   = $this->get_effective_cron_config();

		$event = wp_get_scheduled_event( $hook_name );
		if ( ! $event ) {
			return;
		}

		$current_interval = isset( $event->interval ) ? (int) $event->interval : 0;
		$current_schedule = isset( $event->schedule ) ? $event->schedule : '';

		if ( $current_schedule !== $effective['schedule_name'] || $current_interval !== $effective['interval'] ) {
			self::unschedule( $this->config );
			wp_schedule_event( time(), $effective['schedule_name'], $hook_name );
		}
	}

	/**
	 * Schedule the clean-and-sync cron. Call on activation.
	 */
	public function schedule_clean(): void {
		if ( empty( $this->config['enable_cron'] ) ) {
			return;
		}
		$hook_name = $this->config['cron_clean_hook'] ?? 'd4h_calendar_clean_and_sync';
		$schedule  = $this->config['cron_clean_schedule_name'] ?? 'd4h_calendar_12h';

		if ( ! wp_next_scheduled( $hook_name ) ) {
			wp_schedule_event( time(), $schedule, $hook_name );
		}
	}

	/**
	 * Clear the cron events. Call on uninstall.
	 */
	public static function unschedule( array $config ): void {
		$hook_name = $config['cron_hook'] ?? 'd4h_calendar_sync';
		$next_run  = wp_next_scheduled( $hook_name );
		if ( $next_run ) {
			wp_unschedule_event( $next_run, $hook_name );
		}
		wp_clear_scheduled_hook( $hook_name );

		$clean_hook = $config['cron_clean_hook'] ?? 'd4h_calendar_clean_and_sync';
		$next_run   = wp_next_scheduled( $clean_hook );
		if ( $next_run ) {
			wp_unschedule_event( $next_run, $clean_hook );
		}
		wp_clear_scheduled_hook( $clean_hook );
	}
}
