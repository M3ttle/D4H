<?php
/**
 * Sync: orchestration – run full sync from D4H API to local DB.
 *
 * @package D4H_Calendar
 */

namespace D4H_Calendar;

defined( 'ABSPATH' ) || exit;

final class Sync {

	/** @var array<string, mixed> */
	private $config;

	/** @var API_Client */
	private $api;

	/** @var Repository */
	private $repository;

	/**
	 * @param array<string, mixed> $config
	 * @param API_Client           $api
	 * @param Repository           $repository
	 */
	public function __construct( array $config, API_Client $api, Repository $repository ) {
		$this->config    = $config;
		$this->api       = $api;
		$this->repository = $repository;
	}

	/**
	 * Run full sync: fetch events and exercises, store, update last_updated option.
	 * Optionally fetch tags (only on manual admin update, not cron) to reduce API calls.
	 *
	 * @param bool $sync_tags Whether to fetch and store tags. Default false.
	 * @return true|\WP_Error
	 */
	public function run_full_sync( bool $sync_tags = false ) {
		$context    = function_exists( 'd4h_core_get_context' ) ? d4h_core_get_context() : '';
		$context_id = function_exists( 'd4h_core_get_context_id' ) ? d4h_core_get_context_id() : '';

		if ( empty( $context ) || empty( $context_id ) ) {
			$whoami = $this->api->whoami();
			if ( is_wp_error( $whoami ) ) {
				return $whoami;
			}
			if ( is_array( $whoami ) ) {
				$context    = $context ?: ( $whoami['context'] ?? $whoami['contextType'] ?? '' );
				$context_id = $context_id ?: ( $whoami['id'] ?? $whoami['contextId'] ?? '' );
			}
		}

		if ( empty( $context ) || empty( $context_id ) ) {
			return new \WP_Error( 'd4h_no_context', __( 'Could not determine API context. Set context and context ID in D4H Calendar settings.', 'd4h-calendar' ) );
		}

		$context    = $this->validate_context( $context );
		$context_id = $this->validate_context_id( $context_id );
		if ( $context === '' || $context_id === '' ) {
			return new \WP_Error( 'd4h_invalid_context', __( 'Invalid API context. Context must be "team" or "organisation"; context ID must be alphanumeric.', 'd4h-calendar' ) );
		}

		$events = $this->api->get_events( $context, $context_id );
		if ( is_wp_error( $events ) ) {
			return $events;
		}

		$exercises = $this->api->get_exercises( $context, $context_id );
		if ( is_wp_error( $exercises ) ) {
			return $exercises;
		}

		$items = $this->normalize_activities( $events, 'event' );
		$items = array_merge( $items, $this->normalize_activities( $exercises, 'exercise' ) );

		if ( $sync_tags ) {
			$tags = $this->api->get_tags( $context, $context_id );
			if ( ! is_wp_error( $tags ) ) {
				$tags_map = $this->build_tags_map( $tags );
				update_option( $this->config['option_tags_map'] ?? 'd4h_calendar_tags_map', $tags_map, false );
			}
		}

		$result = $this->repository->replace_activities( $items );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		update_option( $this->config['option_last_updated'] ?? 'd4h_calendar_last_updated', time(), false );
		return true;
	}

	/**
	 * Normalize API items to storage format.
	 *
	 * @param array<int, array<string, mixed>> $raw
	 * @param string                           $resource_type 'event' or 'exercise'
	 * @return array<int, array{id: string, resource_type: string, starts_at: string, ends_at?: string|null, payload: array}>
	 */
	private function normalize_activities( array $raw, string $resource_type ): array {
		$items = array();
		foreach ( $raw as $raw_item ) {
			$id    = isset( $raw_item['id'] ) ? (string) $raw_item['id'] : '';
			$start = isset( $raw_item['startsAt'] ) ? $raw_item['startsAt'] : ( $raw_item['starts_at'] ?? '' );
			$end   = isset( $raw_item['endsAt'] ) ? $raw_item['endsAt'] : ( $raw_item['ends_at'] ?? null );
			if ( $id === '' || $start === '' ) {
				continue;
			}
			$items[] = array(
				'id'            => $id,
				'resource_type' => $resource_type,
				'starts_at'     => is_numeric( $start ) ? gmdate( 'Y-m-d H:i:s', $start ) : $start,
				'ends_at'       => $end !== null && $end !== ''
					? ( is_numeric( $end ) ? gmdate( 'Y-m-d H:i:s', (int) $end ) : $end )
					: null,
				'payload'       => $raw_item,
			);
		}
		return $items;
	}

	/**
	 * Build id => name map from tag objects.
	 *
	 * @param array<int, array<string, mixed>> $tags
	 * @return array<int, string>
	 */
	/**
	 * Validate API context. D4H supports 'team' or 'organisation'.
	 *
	 * @param string $context
	 * @return string Valid context or empty string.
	 */
	private function validate_context( string $context ): string {
		$context = strtolower( trim( $context ) );
		if ( $context === 'team' || $context === 'organisation' ) {
			return $context;
		}
		return '';
	}

	/**
	 * Validate context ID to prevent path injection. Allows alphanumeric and hyphen.
	 *
	 * @param string $context_id
	 * @return string Sanitized ID or empty string if invalid.
	 */
	private function validate_context_id( string $context_id ): string {
		$context_id = trim( $context_id );
		if ( $context_id === '' ) {
			return '';
		}
		if ( preg_match( '/^[a-zA-Z0-9\-]+$/', $context_id ) ) {
			return $context_id;
		}
		return '';
	}

	private function build_tags_map( array $tags ): array {
		$map = array();
		foreach ( $tags as $tag ) {
			$id = isset( $tag['id'] ) ? (int) $tag['id'] : null;
			if ( $id === null ) {
				continue;
			}
			$name = $tag['name'] ?? $tag['label'] ?? $tag['title'] ?? '';
			if ( is_string( $name ) && trim( $name ) !== '' ) {
				$map[ $id ] = trim( $name );
			}
		}
		return $map;
	}
}
